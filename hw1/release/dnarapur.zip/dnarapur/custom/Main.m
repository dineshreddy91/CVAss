#computeDictionary()
#batchToVisualWords(20)
buildRecognitionSystem
evaluateRecognitionSystem
