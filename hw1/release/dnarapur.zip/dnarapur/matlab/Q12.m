% pkg load image
% pkg load io
% pkg load statistics
computeDictionary()
